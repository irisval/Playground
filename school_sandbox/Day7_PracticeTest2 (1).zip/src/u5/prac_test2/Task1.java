package u5.prac_test2;

public class Task1 {

	public static double percentVowels (String s) throws UnexpectedCharacterException
	{
	}
	
	public static void main(String[] args) {
		String[] s = {"Happy", "Jackson", "School Days", "Gr4et", "AeIoU", "b", "16"};

		for (int i=0; i<s.length; i++)
		{
			try {
				System.out.print(s[i] + ": ");
				System.out.printf("%.1f%%\n", percentVowels(s[i]));
			}catch (UnexpectedCharacterException ex) {
				System.out.println("Illegal characters in string!");
			}
		}
	}
}
