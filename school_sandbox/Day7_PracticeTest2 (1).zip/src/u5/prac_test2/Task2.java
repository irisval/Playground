package u5.prac_test2;

import java.io.File;
import java.util.Scanner;

public class Task2 {
	public static void main(String[] args) {
		File f = new File("Nothing");
		Scanner s = new Scanner(f);
		System.out.println("Hello world");
		s.close();
	}
}
